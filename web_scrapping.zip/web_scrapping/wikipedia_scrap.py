import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import requests
from bs4 import BeautifulSoup
import pandas as pd
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------- SCRAPING FUNCTION ---------------- #

def scrape_website():

    url = url_entry.get().strip()

    if not url:
        messagebox.showwarning("Missing URL", "Please enter a website URL.")
        return

    try:
        headers = {
            "User-Agent": "MyWikipediaScraper/1.0 (your-email@example.com)"
        }

        response = requests.get(
            url,
            headers=headers,
            verify=False,
            timeout=15
        )

        if response.status_code != 200:
            messagebox.showerror(
                "Error",
                f"Website returned status code {response.status_code}"
            )
            return

        soup = BeautifulSoup(response.text, "html.parser")

        # Main article for Wikipedia
        article = soup.find("div", class_="mw-parser-output")

        if article is None:
            article = soup.body

        data.clear()

        # -------- HEADINGS -------- #

        if heading_var.get():
            elements = article.find_all(["h1", "h2", "h3"])

            for element in elements:

                text = element.get_text(" ", strip=True)

                if text:
                    data.append({
                        "Type": "Heading",
                        "Tag": element.name,
                        "Class": " ".join(element.get("class", [])),
                        "ID": element.get("id", ""),
                        "Content": text,
                        "Source": ""
                    })

        # -------- PARAGRAPHS -------- #

        if paragraph_var.get():
            elements = article.find_all("p")

            for element in elements:

                text = element.get_text(" ", strip=True)

                if text:
                    data.append({
                        "Type": "Paragraph",
                        "Tag": "p",
                        "Class": " ".join(element.get("class", [])),
                        "ID": element.get("id", ""),
                        "Content": text,
                        "Source": ""
                    })

        # -------- IMAGES -------- #

        if image_var.get():
            elements = article.find_all("img")

            for element in elements:

                src = element.get("src", "")

                data.append({
                    "Type": "Image",
                    "Tag": "img",
                    "Class": " ".join(element.get("class", [])),
                    "ID": element.get("id", ""),
                    "Content": element.get("alt", ""),
                    "Source": src
                })

        # -------- TABLES -------- #

        if table_var.get():
            elements = article.find_all("table")

            for element in elements:

                text = element.get_text(" ", strip=True)

                if text:
                    data.append({
                        "Type": "Table",
                        "Tag": "table",
                        "Class": " ".join(element.get("class", [])),
                        "ID": element.get("id", ""),
                        "Content": text,
                        "Source": ""
                    })

        # -------- DISPLAY DATA -------- #

        for row in tree.get_children():
            tree.delete(row)

        for item in data:

            tree.insert(
                "",
                "end",
                values=(
                    item["Type"],
                    item["Tag"],
                    item["Class"],
                    item["ID"],
                    item["Content"][:150]
                )
            )

        status_label.config(
            text=f"✓ Scraping completed — {len(data)} elements found"
        )

    except Exception as e:

        messagebox.showerror(
            "Scraping Error",
            str(e)
        )


# ---------------- EXPORT FUNCTION ---------------- #

def export_csv():

    if not data:
        messagebox.showwarning(
            "No Data",
            "Please scrape a website first."
        )
        return

    file_path = filedialog.asksaveasfilename(
        defaultextension=".csv",
        filetypes=[
            ("CSV Files", "*.csv")
        ],
        title="Save Scraped Data"
    )

    if file_path:

        df = pd.DataFrame(data)

        df.to_csv(
            file_path,
            index=False,
            encoding="utf-8-sig"
        )

        messagebox.showinfo(
            "Success",
            "CSV file saved successfully!"
        )


# ---------------- MAIN WINDOW ---------------- #

root = tk.Tk()

root.title("Web Scraper")
root.geometry("1100x700")
root.minsize(900, 600)

root.configure(bg="#f5f7fa")


# ---------------- STYLE ---------------- #

style = ttk.Style()

style.theme_use("clam")

style.configure(
    "Treeview",
    rowheight=32,
    font=("Segoe UI", 10)
)

style.configure(
    "Treeview.Heading",
    font=("Segoe UI", 10, "bold")
)

style.configure(
    "TButton",
    font=("Segoe UI", 10, "bold"),
    padding=10
)


# ---------------- HEADER ---------------- #

header = tk.Frame(
    root,
    bg="#ffffff",
    height=90
)

header.pack(
    fill="x"
)

title = tk.Label(
    header,
    text="Web Scraper",
    font=("Segoe UI", 24, "bold"),
    bg="#ffffff",
    fg="#202124"
)

title.pack(
    anchor="w",
    padx=30,
    pady=(18, 0)
)

subtitle = tk.Label(
    header,
    text="Extract and organize webpage content",
    font=("Segoe UI", 10),
    bg="#ffffff",
    fg="#6b7280"
)

subtitle.pack(
    anchor="w",
    padx=32
)


# ---------------- MAIN CONTENT ---------------- #

main = tk.Frame(
    root,
    bg="#f5f7fa"
)

main.pack(
    fill="both",
    expand=True,
    padx=30,
    pady=20
)


# ---------------- URL ---------------- #

url_label = tk.Label(
    main,
    text="Website URL",
    font=("Segoe UI", 11, "bold"),
    bg="#f5f7fa",
    fg="#202124"
)

url_label.pack(
    anchor="w"
)

url_entry = ttk.Entry(
    main,
    font=("Segoe UI", 11)
)

url_entry.pack(
    fill="x",
    pady=(7, 15),
    ipady=7
)

url_entry.insert(
    0,
    "https://en.wikipedia.org/wiki/Python_(programming_language)"
)


# ---------------- CHECKBOXES ---------------- #

options_label = tk.Label(
    main,
    text="Content to scrape",
    font=("Segoe UI", 11, "bold"),
    bg="#f5f7fa"
)

options_label.pack(
    anchor="w"
)

options_frame = tk.Frame(
    main,
    bg="#f5f7fa"
)

options_frame.pack(
    anchor="w",
    pady=8
)

heading_var = tk.BooleanVar(value=True)
paragraph_var = tk.BooleanVar(value=True)
image_var = tk.BooleanVar(value=True)
table_var = tk.BooleanVar(value=True)

tk.Checkbutton(
    options_frame,
    text="Headings",
    variable=heading_var,
    bg="#f5f7fa",
    font=("Segoe UI", 10)
).pack(side="left", padx=(0, 20))

tk.Checkbutton(
    options_frame,
    text="Paragraphs",
    variable=paragraph_var,
    bg="#f5f7fa",
    font=("Segoe UI", 10)
).pack(side="left", padx=20)

tk.Checkbutton(
    options_frame,
    text="Images",
    variable=image_var,
    bg="#f5f7fa",
    font=("Segoe UI", 10)
).pack(side="left", padx=20)

tk.Checkbutton(
    options_frame,
    text="Tables",
    variable=table_var,
    bg="#f5f7fa",
    font=("Segoe UI", 10)
).pack(side="left", padx=20)


# ---------------- BUTTONS ---------------- #

button_frame = tk.Frame(
    main,
    bg="#f5f7fa"
)

button_frame.pack(
    anchor="w",
    pady=10
)

scrape_button = ttk.Button(
    button_frame,
    text="  Scrape Website  ",
    command=scrape_website
)

scrape_button.pack(
    side="left",
    padx=(0, 10)
)

export_button = ttk.Button(
    button_frame,
    text="  Export to CSV  ",
    command=export_csv
)

export_button.pack(
    side="left"
)


# ---------------- STATUS ---------------- #

status_label = tk.Label(
    main,
    text="Ready to scrape",
    font=("Segoe UI", 10),
    bg="#f5f7fa",
    fg="#6b7280"
)

status_label.pack(
    anchor="w",
    pady=(5, 10)
)


# ---------------- TABLE ---------------- #

table_frame = tk.Frame(
    main,
    bg="#ffffff"
)

table_frame.pack(
    fill="both",
    expand=True
)

columns = (
    "Type",
    "Tag",
    "Class",
    "ID",
    "Content"
)

tree = ttk.Treeview(
    table_frame,
    columns=columns,
    show="headings"
)

tree.heading("Type", text="Type")
tree.heading("Tag", text="Tag")
tree.heading("Class", text="Class")
tree.heading("ID", text="ID")
tree.heading("Content", text="Content")

tree.column("Type", width=100)
tree.column("Tag", width=70)
tree.column("Class", width=180)
tree.column("ID", width=120)
tree.column("Content", width=500)

scrollbar = ttk.Scrollbar(
    table_frame,
    orient="vertical",
    command=tree.yview
)

tree.configure(
    yscrollcommand=scrollbar.set
)

tree.pack(
    side="left",
    fill="both",
    expand=True
)

scrollbar.pack(
    side="right",
    fill="y"
)


# ---------------- DATA ---------------- #

data = []


root.mainloop()
